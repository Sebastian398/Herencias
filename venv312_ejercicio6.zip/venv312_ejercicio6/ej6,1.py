#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importan las librerias
import modules.clases1 as clases
from colorama import Fore

'''
Este programa muestra una serie de clases con datos sobre distintos usuarios del sena y como esas clases heredan datos de las superclases
'''

def main():    
    
    #Se instancia la clase
    libro1 = clases.Revista()

    #Se solicitan los datos al usuario
    libro1.set_codigo (int(input(Fore.BLUE+"codigo de la revista: ")))

    print("Codigo de la revista", libro1.get_codigo())

    libro1.set_titulo(input("titulo de la revista: "))

    print("Titulo de la revista", libro1.get_titulo())
    
    libro1.set_autor (input("Indique el nombre del autor: "))
    
    print("El nombre del autor es", libro1.get_autor())
    
    #Se solicitan los datos al usuario
    libro1.set_editorial (input("editorial de la revista: "))

    print("Editorial de la revista", libro1.get_editorial())

    libro1.set_año (int(input("año de publicacion: ")))

    print("Año de publicacion", libro1.get_año())

    libro1.set_precio (int(input("precio de la revista: ")))

    print("Precio de la revista", libro1.get_precio())
       
   
    #Se solicita el dato al usuario
    libro1.set_volumen (input("volumen de la revista: "))

    print("Volumen de la revista", libro1.get_volumen())
    
    libro1.estado()
    libro1.informacion()

    #Se instancia la clase
    libro2 = clases.Libro()  

    #Se solicitan los datos al usuario
    libro2.set_codigo (int(input(Fore.CYAN+"codigo del libro: ")))

    print("Codigo del libro", libro2.get_codigo())

    libro2.set_titulo(input("titulo del libro: "))

    print("Titulo del libro", libro2.get_titulo())

    libro2.set_autor (input("Indique el nombre del autor: "))
    
    print("El nombre del autor es", libro2.get_autor())
    
    #Se solicitan los datos al usuario
    libro2.set_editorial (input("editorial del producto: "))

    print("Editorial del producto", libro2.get_editorial())

    libro2.set_año (int(input("año de publicacion: ")))

    print("Año de publicacion", libro2.get_año())

    libro2.set_precio (int(input("precio del producto: ")))

    print("Precio del producto", libro2.get_precio())
    
    
    #Se solicita el dato al usuario
    libro2.set_idioma (input("idioma del libro: "))

    print("Idioma del libro", libro2.get_idioma())
    
    libro2.estado()
    libro2.informacion()

    #Se instancia la clase
    libro3 = clases.Producto_grabado()

    #Se solicitan los datos al usuario
    libro3.set_codigo (int(input(Fore.GREEN+"codigo del producto: ")))

    print("Codigo del producto", libro3.get_codigo())

    libro3.set_titulo(input("titulo del producto: "))

    print("Titulo del producto", libro3.get_titulo())  
    
    libro3.set_autor (input("Indique el nombre del autor: "))
    
    print("El nombre del autor es", libro3.get_autor())
    
    #Se solicitan los datos al usuario
    libro3.set_tiempo_duracion (input("tiempo de duracion del producto en minutos: "))
    print("El tiempo de duracion en minutos es", libro3.get_tiempo_duracion())
    
    libro3.set_medio_tecnologico (input("medio tecnologico donde se muestra: "))
    print("El medio tecnologico donde se muestra es", libro3.get_medio_tecnologico())
    
    libro3.informacion() 
    
    #Se instancia la clase
    libro4 = clases.Producto_software()

    #Se solicitan los datos al usuario
    libro4.set_codigo (int(input(Fore.LIGHTRED_EX+"codigo del software: ")))

    print("Codigo del software", libro4.get_codigo())

    libro4.set_titulo(input("titulo del software: "))

    print("Titulo del software", libro4.get_titulo())

    libro4.set_autor (input("Indique el nombre del autor: "))
    
    print("El nombre del autor es", libro4.get_autor())
    
    #Se solicitan los datos al usuario
    libro4.set_version (input("version del producto: "))
    print("La version del producto es", libro4.get_version())

    libro4.set_sistema_operativo (input("sistema operativo del producto: "))
    print("El sistema operativo del producto es", libro4.get_sistema_operativo())
    
    libro4.informacion()
        
if __name__ == "__main__":
    
    #Se ejecuta el programa 
    main()