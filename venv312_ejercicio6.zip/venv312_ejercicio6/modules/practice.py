from random import randint
from datetime import datetime, timedelta
class Instructor_contrato():

    #Se establecen los atributos
    def __init__(self, duracion_contrato=0, fecha_vinculacion='%Y-%m-%d', profesion='', salario_basico=0, name='', document=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document, profesion, salario_basico,)
        
        self.__duracion_contrato = duracion_contrato
        self.__fecha_vinculacion = datetime.strptime(fecha_vinculacion, '%Y-%m-%d')

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_duracion_contrato(self, value):
        self.__duracion_contrato = value

    def get_duracion_contrato(self):
        return self.__duracion_contrato

    #La funcion set_fecha_vinculacion usa el formato de la libreria datetime para establecer la fecha   
    def set_fecha_vinculacion(self, value):
        self.__fecha_vinculacion = datetime.strptime(value, '%d-%m-%Y')

    def get_fecha_vinculacion(self):
        return self.__fecha_vinculacion

    #La funcion estado determina la fecha en que termina el contrato del instructor
    def estado(self):
         return self.get_fecha_vinculacion() + timedelta(days=self.get_duracion_contrato()*30)

    #La funcion sueldo calcula el total del sueldo del instructor teniendo en cuenta el grado que tiene
    def sueldo(self):
        sueldos = (randint(1,21) * 100000) + 1500000
        return sueldos

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('La duracion del contrato es {0}, la fecha de vinculacion es {1}, el contrato caduca el {2} y el sueldo del instructor es {3}'.format(self.get_duracion_contrato(), 
                                                                                                                                                    self.get_fecha_vinculacion().strftime('%d-%m-%Y'),
                                                                                                                                                    self.estado().strftime('%d-%m-%Y'),
                                                                                                                                                    self.sueldo()))