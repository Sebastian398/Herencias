#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importa la libreria
from random import randint

'''
Este programa crea distintas clases que almacenan datos y permiten que las subclases hereden datos de las super clases
'''

#Se crea la clase Producto
class Producto:

    #Se establecen los atributos
    def __init__(self, codigo=0, titulo='', autor=''):
        self.__codigo = codigo
        self.__titulo = titulo
        self.__autor = autor

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_codigo(self,value):
        self.__codigo = value
    
    def get_codigo(self):
        return self.__codigo
    
    def set_titulo(self,value):
        self.__titulo= value

    def get_titulo(self):
        return self.__titulo
    
    def set_autor(self,value):
        self.__autor= value

    def get_autor(self):
        return self.__autor

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El codigo es {0} y el titulo es {1}'.format(self.get_codigo(), self.get_titulo(), end=""))


#Se crea la clase Producto_impreso
class Producto_impreso(Producto):

    #Se establecen los atributos
    def __init__(self, codigo=0, titulo='', editorial='', año=0, precio=0, autor=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(codigo, titulo, autor)
        
        self.__editorial = editorial
        self.__año = año
        self.__precio = precio

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_editorial(self,value):
        self.__editorial = value
    
    def get_editorial(self):
        return self.__editorial
    
    def set_año(self,value):
        self.__año= value

    def get_año(self):
        return self.__año
    
    def set_precio(self,value):
        self.__precio= value

    def get_precio(self):
        return self.__precio

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('La editorial es {0}, el año es {1} y el precio es {2}'.format(self.get_editorial(), self.get_año(), self.get_precio()))

#Se crea la clase Revista
class Revista(Producto_impreso):

    #Se establece el atributo
    def __init__(self, volumen=0, codigo=0, titulo='', editorial='', año=0, precio=0, autor=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(editorial, año, precio, codigo, titulo, autor)
        
        self.__volumen = volumen

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_volumen(self,value):
        self.__volumen = value
    
    def get_volumen(self):
        return self.__volumen
    
    #La funcion estado determina en cual de las opciones se encuentra la revista
    def estado(self):
        estados = ["Nuevo", "Usado"]
        alt = randint(0, len(estados)-1)
        return estados[alt]


    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El volumen es {0} y el estado es {1}'.format(self.get_volumen(), self.estado(), end=""))

class Libro(Producto_impreso):

    #Se establece el atributo
    def __init__(self, idioma='', editorial='', año=0, precio=0, autor=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(editorial, año, precio, autor)
        
        self.__idioma = idioma

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_idioma(self,value):
        self.__idioma = value
    
    def get_idioma(self):
        return self.__idioma
    
    #La funcion estado determina en cual de las opciones se encuentra el libro
    def estado(self):
        estados = ["Nuevo", "Usado"]
        alt = randint(0, len(estados)-1)
        return estados[alt]


    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El idioma es {0} y el estado es {1}'.format(self.get_idioma(), self.estado(), end=""))

#Se crea la clase Producto_grabado
class Producto_grabado(Producto):

    #Se establecen los atributos
    def __init__(self,codigo=0, titulo='', tiempo_duracion=0, medio_tecnologico='', autor=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(codigo, titulo, autor)
        
        self.__tiempo_duracion = tiempo_duracion
        self.__medio_tecnologico = medio_tecnologico

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_tiempo_duracion(self,value):
        self.__tiempo_duracion = value
    
    def get_tiempo_duracion(self):
        return self.__tiempo_duracion
    
    def set_medio_tecnologico(self,value):
        self.__medio_tecnologico= value

    def get_medio_tecnologico(self):
        return self.__medio_tecnologico

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El tiempo de duracion es {0} minutos y el medio tecnologico es {1}'.format(self.get_tiempo_duracion(), self.get_medio_tecnologico(), end=""))

#Se crea la clase Producto_software
class Producto_software(Producto):

    #Se establecen los atributos
    def __init__(self,codigo=0, titulo='', version='', sistema_operativo=0, autor=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(codigo, titulo, autor)
        
        self.__version = version
        self.__sistema_operativo = sistema_operativo

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_version(self,value):
        self.__version = value
    
    def get_version(self):
        return self.__version
    
    def set_sistema_operativo(self,value):
        self.__sistema_operativo= value

    def get_sistema_operativo(self):
        return self.__sistema_operativo

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('La version es {0} y el sistema operativo es {1}'.format(self.get_version(), self.get_sistema_operativo(), end=""))