#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importan las librerias
from random import randint
from datetime import datetime,timedelta

'''
Este programa crea distintas clases que almacenan datos y permiten que las subclases hereden datos de las super clases
'''

#Se crea la clase Persona
class Persona:

    #Se establecen los atributos
    def __init__(self, document='0', name=''):
        self.__document = document
        self.__name = name

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_document(self,value):
        self.__document = value
    
    def get_document(self):
        return self.__document
    
    def set_name(self,value):
        self.__name = value

    def get_name(self):
        return self.__name

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El numero de documento es {0} y mi nombre es {1}'.format(self.get_document(), self.get_name(), end=""))

#Se crea la clase Aprendiz
class Aprendiz(Persona):

    #Se establecen los atributos
    def __init__(self, ficha=0, programa='', name='', document=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(name='', document=0)

        self.__programa = programa
        self.__ficha = ficha

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_programa(self,value):
        self.__programa = value
    
    def get_programa(self):
        return self.__programa
    
    def set_ficha(self,value):
        self.__ficha = value

    def get_ficha(self):
        return self.__ficha
    
    def matricula(self):
        return "Matriculado"
        
    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El programa es {0}, el numero de ficha es {1}, y el estudiante se encuentra {2}'.format(self.get_programa(), 
                                                                                                       self.get_ficha(), 
                                                                                                       self.matricula(),end=""))

#Se crea la clase Etapa_lectiva
class Etapa_lectiva(Aprendiz):

    #Se establecen los atributos
    def __init__(self, ficha=0, programa='', name='', document=0, numero_trimestre='', fecha_inicio='', fecha_termminacion=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document, ficha, programa)
        
        self.__numero_trimestre = numero_trimestre
        self.__fecha_inicio = fecha_inicio
        self.__fecha_terminacion = fecha_termminacion

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_numero_trimestre(self,value):
        self.__numero_trimestre = value
    
    def get_numero_trimestre(self):
        return self.__numero_trimestre
    
    def set_fecha_inicio(self,value):
        self.__fecha_inicio = value

    def get_fecha_inicio(self):
        return self.__fecha_inicio
    
    def set_fecha_terminacion(self,value):
        self.__fecha_terminacion = value
     
    def get_fecha_terminacion(self):
        return self.__fecha_terminacion
    
    #La funcion estado determina en cual de las opciones se encuentra el aprendiz
    def estado(self):
        estados = ["En induccion", "En formacion", "En formacion", "Aplazdo", "Condicionado", "Retirado"]
        alt = randint(0, len(estados)-1)
        return estados[alt]

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        
        estado = self.estado()
        print('El numero de trimestre es {0}, la fecha de inicio es {1}, la fecha de terminacion es {2} y el estado del aprendiz es {3}'.format(self.get_numero_trimestre(), 
                                                                                                                                                self.get_fecha_inicio(), 
                                                                                                                                                self.get_fecha_terminacion(), 
                                                                                                                                                self.estado(),
                                                                                                                                                end=""))
    

#Se crea la clase Etapa_practica
class Etapa_practica(Aprendiz):

    #Se establecen los atributos
    def __init__(self, ficha=0, programa='', name='', document=0, modalidad='', fecha_inicio='', fecha_termminacion=''):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document, ficha, programa)
        
        self.__modalidad = modalidad
        self.__fecha_inicio = fecha_inicio
        self.__fecha_terminacion = fecha_termminacion

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_modalidad(self,value):
        self.__modalidad = value
    
    def get_modalidad(self):
        return self.__modalidad
    
    def set_fecha_inicio(self,value):
        self.__fecha_inicio = value

    def get_fecha_inicio(self):
        return self.__fecha_inicio
    
    def set_fecha_terminacion(self,value):
        self.__fecha_terminacion = value
     
    def get_fecha_terminacion(self):
        return self.__fecha_terminacion
    
    #La funcion estado determina en cual de las opciones se encuentra el aprendiz
    def estado(self):
        
        estados = ["En induccion", "En formacion", "En formacion", "Aplazdo", "Condicionado", "Retirado"]
        alt = randint(0, len(estados)-1)
        return estados[alt]

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        
        estado = self.estado()
        print('La modalidad es {0}, la fecha de inicio es {1}, la fecha de terminacion es {2} y el estado del aprendiz es {3}'.format(self.get_modalidad(), 
                                                                                                                                      self.get_fecha_inicio(), 
                                                                                                                                      self.get_fecha_terminacion(), 
                                                                                                                                      estado, 
                                                                                                                                      end=""))

#Se crea la clase Instructor        
class Instructor(Persona):

    #Se establecen los atributos
    def __init__(self, profesion='', salario_basico=0, name='', document=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document)

        self.__salario_basico = salario_basico
        self.__profesion = profesion

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_salario_basico(self,value):
        self.__salario_basico = value
    
    def get_salario_basico(self):
        return 1500000
    
    def set_profesion(self,value):
        self.__profesion = value

    def get_profesion(self):
        return self.__profesion
    
    #La funcion contrato determina en cual de las opciones se encuentra el contrato del instructor
    def contrato(self):
        contrataciones = ["termino fijo", "obra labor"]
        alt = randint (0, len(contrataciones)-1)
        return contrataciones[alt]
        
    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        contrato = self.contrato()
        print('El salario basico es {0}, la profesion es {1}, y el instructor tiene un contrato {2}'.format(self.get_salario_basico(), 
                                                                                                            self.get_profesion(), self.contrato(),
                                                                                                            end=""))

#Se crea la clase Instructor_planta    
class Instructor_planta(Instructor):

    #Se establecen los atributos
    def __init__(self, grado=0, fecha_vinculacion='', profesion='', salario_basico=0, name='', document=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document, profesion, salario_basico)
        
        self.__grado = grado
        self.__fecha_vinculacion = fecha_vinculacion

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_grado(self, value):
        self.__grado = value

    #la funcion get_grado devuelve el valor del grado en que se encuentra el instructor
    def get_grado(self):
        return self.__grado

    def set_fecha_vinculacion(self, value):
        self.__fecha_vinculacion = value

    def get_fecha_vinculacion(self):
        return self.__fecha_vinculacion

    #La funcion estado determina en cual de las opciones se encuentra el instructor
    def estado(self):
        estados = ["En induccion", "En formacion", "En formacion", "Aplazado", "Condicionado", "Retirado"]
        alt = randint(0, len(estados)-1)
        return estados[alt]

    #La funcion sueldo calcula el total del sueldo del instructor teniendo en cuenta el grado que tiene
    def sueldo(self):
        sueldos = (self.get_grado() * 100000) + 1500000
        return sueldos

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('El grado es {0}, la fecha de vinculacion es {1}, el estado es {2} y el sueldo del instructor es {3}'.format(self.get_grado(), 
                                                                                                                            self.get_fecha_vinculacion(),
                                                                                                                            self.estado(),
                                                                                                                            self.sueldo()))

#Se crea la clase Instructor_contrato        
class Instructor_contrato(Instructor):

    #Se establecen los atributos
    def _init_(self, duracion_contrato=0, fecha_vinculacion='', profesion='', salario_basico=0, name='', document=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(name, document, profesion, salario_basico,)
        
        self.__duracion_contrato = duracion_contrato
        self.__fecha_vinculacion = datetime.strptime(fecha_vinculacion, '%Y-%m-%d')

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_duracion_contrato(self, value):
        self.__duracion_contrato = value

    def get_duracion_contrato(self):
        return self.__duracion_contrato

    #La funcion set_fecha_vinculacion usa el formato de la libreria datetime para establecer la fecha   
    def set_fecha_vinculacion(self, value):
        self.__fecha_vinculacion = datetime.strptime(value, '%d-%m-%Y')

    def get_fecha_vinculacion(self):
        return self.__fecha_vinculacion

    #La funcion estado determina la fecha en que termina el contrato del instructor
    def estado(self):
         return self.get_fecha_vinculacion() + timedelta(days=self.get_duracion_contrato()*30)

    #La funcion sueldo calcula el total del sueldo del instructor teniendo en cuenta el grado que tiene
    def sueldo(self):
        sueldos = (randint(1,21) * 100000) + 1500000
        return sueldos

    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('La duracion del contrato es {0}, la fecha de vinculacion es {1}, el contrato caduca el {2} y el sueldo del instructor es {3}'.format(self.get_duracion_contrato(), 
                                                                                                                                                    self.get_fecha_vinculacion().strftime('%d-%m-%Y'),
                                                                                                                                                    self.estado().strftime('%d-%m-%Y'),
                                                                                                                                                    self.sueldo()))