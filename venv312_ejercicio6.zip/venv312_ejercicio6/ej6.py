#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importa la libreria
import modules.clases as clases
from colorama import Fore

'''
Este programa muestra una serie de clases con datos sobre distintos usuarios del sena y como esas clases heredan datos de las superclases
'''

def main():    
    
    #Se instancia la clase
    aprendiz1 = clases.Etapa_lectiva()

    #Se solicitan los datos al usuario
    aprendiz1.set_document (int(input(Fore.BLUE+"documento del aprendiz: ")))

    print("Documento del aprendiz", aprendiz1.get_document())

    aprendiz1.set_name(input("nombre del aprendiz: "))

    print("Nombre del aprendiz", aprendiz1.get_name())

    aprendiz1.set_programa (input("programa del aprendiz: "))

    print("Programa del aprendiz", aprendiz1.get_programa())

    aprendiz1.set_ficha (int(input("ficha del aprendiz: ")))

    print("Ficha del aprendiz", aprendiz1.get_ficha())
    
    #Se muestra el metodo matricula
    print(aprendiz1.matricula())
    
    aprendiz1.set_numero_trimestre (int(input("numero de trimestre del aprendiz: ")))

    print("Numero de trimestre del aprendiz", aprendiz1.get_numero_trimestre())

    aprendiz1.set_fecha_inicio (input("fecha de inicio del trimestre del aprendiz: "))

    print("Fecha de inicio del trimestre del aprendiz", aprendiz1.get_fecha_inicio())

    aprendiz1.set_fecha_terminacion (input("fecha de terminacion del trimestre del aprendiz: "))

    print("Fecha de terminacion del trimestre del aprendiz", aprendiz1.get_fecha_terminacion())
    
    aprendiz1.informacion()

    #Se instancia la clase
    aprendiz2 = clases.Etapa_practica()    
    
    #Se solicitan los datos al usuario
    aprendiz2.set_document (int(input(Fore.CYAN+"documento del aprendiz: ")))

    print("Documento del aprendiz", aprendiz2.get_document())

    aprendiz2.set_name(input("nombre del aprendiz: "))

    print("Nombre del aprendiz", aprendiz2.get_name())

    aprendiz2.set_programa (input("programa del aprendiz: "))

    print("Programa del aprendiz", aprendiz2.get_programa())

    aprendiz2.set_ficha (int(input("ficha del aprendiz: ")))

    print("Ficha del aprendiz", aprendiz2.get_ficha())
    
    #Se muestra el metodo matricula
    print(aprendiz2.matricula())

    aprendiz2.set_modalidad (input("modalidad del aprendiz: "))

    print("modalidad del aprendiz", aprendiz2.get_modalidad())

    aprendiz2.set_fecha_inicio (input("fecha de inicio del trimestre del aprendiz: "))

    print("Fecha de inicio del trimestre del aprendiz", aprendiz2.get_fecha_inicio())

    aprendiz2.set_fecha_terminacion (input("fecha de terminacion del trimestre del aprendiz: "))

    print("Fecha de terminacion del trimestre del aprendiz", aprendiz2.get_fecha_terminacion())
    
    aprendiz2.informacion()

    #Se instancia la clase
    instructor = clases.Instructor_planta()
    
    #Se solicita el dato al usuario
    instructor.set_profesion (input(Fore.GREEN+"profesion del instructor: "))

    #Muestra cual es el salario basico del instructor
    print("Salario basico del instructor es", instructor.get_salario_basico())

    print("Profesion del instructor", instructor.get_profesion())
    instructor.contrato()
    
    #Se solicita los datos al usuario
    instructor.set_grado (int(input("Indique el grado: ")))
    instructor.set_fecha_vinculacion (input("fecha de vinculacion del instructor: "))
    
    print("Fecha de vinculacion del instructor", instructor.get_fecha_vinculacion())
    instructor.estado()
    instructor.sueldo()
    instructor.informacion()

    #Se instancia la clase
    instructor2 = clases.Instructor_contrato()  
    
    #Se solicita el dato al usuario
    instructor2.set_profesion (input(Fore.LIGHTRED_EX+"profesion del instructor: "))

    #Muestra cual es el salario basico del instructor
    print("Salario basico del instructor es", instructor2.get_salario_basico())

    print("Profesion del instructor", instructor2.get_profesion())
    instructor2.contrato()

    #Se solicitan los datos al usuario
    instructor2.set_duracion_contrato (int(input("duracion del contrato por cantidad de meses:")))
    print("Duracion del contrato", instructor2.get_duracion_contrato())

    instructor2.set_fecha_vinculacion (input("fecha de vinculacion del instructor en formato dd-mm-aaaa: "))
    
    print("Fecha de vinculacion del instructor", instructor2.get_fecha_vinculacion())
    
    instructor2.estado()
    instructor2.sueldo()
    instructor2.informacion()

if __name__ == "__main__":
    
    #Se ejecuta el programa 
    main()